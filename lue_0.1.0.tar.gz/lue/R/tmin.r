#' @title Minimum temperature data
#' @docType data
#' @name tmin
#' @usage tmin
#' @format A raster (.nc)
#' @description Input minimum temperature dataset
#' @keywords datasets
NULL
