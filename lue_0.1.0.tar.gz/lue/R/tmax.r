#' @title Maximum temperature data
#' @docType data
#' @name tmax
#' @usage tmax
#' @format A rasterbrick (.nc)
#' @description Input maximum temperature dataset
#' @keywords datasets
NULL
