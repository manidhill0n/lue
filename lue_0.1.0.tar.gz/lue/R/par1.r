#' @title Photosynthetically Active Radiation
#' @docType data
#' @name par1
#' @usage par1
#' @format A rasterbrick (.nc)
#' @description Input par dataset
#' @keywords datasets
NULL
