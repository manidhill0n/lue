#' @title Fpar data
#' @docType data
#' @name fpar
#' @usage fpar
#' @format A raster (.tif)
#' @description Input datasets
#' @keywords datasets
NULL
