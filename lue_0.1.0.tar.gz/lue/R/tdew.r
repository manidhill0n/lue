#' @title Dewpoint Temperature
#' @docType data
#' @name tdew
#' @usage tdew
#' @format A rasterbrick (.nc)
#' @description Input dewpoint temperature dataset
#' @keywords datasets
NULL
